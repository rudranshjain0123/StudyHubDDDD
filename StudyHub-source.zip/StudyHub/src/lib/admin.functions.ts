import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

import { z } from "zod";

const CreateInput = z.object({
  displayName: z.string().min(2).max(60),
  passcode: z.string().min(6).max(120),
  isAdmin: z.boolean().default(false),
});

const UpdateInput = z.object({
  userId: z.string().uuid(),
  displayName: z.string().min(2).max(60).optional(),
  passcode: z.string().min(6).max(120).optional(),
});

const DeleteInput = z.object({ userId: z.string().uuid() });



export const listMembers = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { assertAdmin } = await import("@/lib/admin-guard.server");
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const [{ data: profiles }, { data: roles }] = await Promise.all([
      supabaseAdmin.from("profiles").select("id, display_name, created_at").order("display_name"),
      supabaseAdmin.from("user_roles").select("user_id, role"),
    ]);

    const adminIds = new Set((roles ?? []).filter((r) => r.role === "admin").map((r) => r.user_id));
    return (profiles ?? []).map((p) => ({
      id: p.id,
      displayName: p.display_name,
      createdAt: p.created_at,
      isAdmin: adminIds.has(p.id),
    }));
  });

export const createMember = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => CreateInput.parse(input))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("@/lib/admin-guard.server");
    await assertAdmin(context.supabase, context.userId);
    const { hashPasscode, synthEmail } = await import("@/lib/passcode.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const hash = hashPasscode(data.passcode);
    const { data: clash } = await supabaseAdmin
      .from("member_credentials")
      .select("user_id")
      .eq("passcode_hash", hash)
      .maybeSingle();
    if (clash) return { ok: false as const, error: "That passcode is already in use." };

    const email = synthEmail(data.displayName);
    const { data: created, error } = await supabaseAdmin.auth.admin.createUser({
      email,
      password: data.passcode.trim(),
      email_confirm: true,
    });
    if (error || !created.user) {
      return { ok: false as const, error: error?.message ?? "Could not create that member." };
    }

    const userId = created.user.id;
    await supabaseAdmin.from("profiles").insert({ id: userId, display_name: data.displayName });
    await supabaseAdmin
      .from("user_roles")
      .insert({ user_id: userId, role: data.isAdmin ? "admin" : "member" });
    await supabaseAdmin
      .from("member_credentials")
      .insert({ user_id: userId, email, passcode_hash: hash });

    return { ok: true as const };
  });

export const updateMember = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => UpdateInput.parse(input))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("@/lib/admin-guard.server");
    await assertAdmin(context.supabase, context.userId);
    const { hashPasscode } = await import("@/lib/passcode.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    if (data.displayName) {
      await supabaseAdmin
        .from("profiles")
        .update({ display_name: data.displayName })
        .eq("id", data.userId);
    }

    if (data.passcode) {
      const hash = hashPasscode(data.passcode);
      const { data: clash } = await supabaseAdmin
        .from("member_credentials")
        .select("user_id")
        .eq("passcode_hash", hash)
        .maybeSingle();
      if (clash && clash.user_id !== data.userId) {
        return { ok: false as const, error: "That passcode is already in use." };
      }
      const { error } = await supabaseAdmin.auth.admin.updateUserById(data.userId, {
        password: data.passcode.trim(),
      });
      if (error) return { ok: false as const, error: error.message };
      await supabaseAdmin
        .from("member_credentials")
        .update({ passcode_hash: hash })
        .eq("user_id", data.userId);
    }

    return { ok: true as const };
  });

export const deleteMember = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => DeleteInput.parse(input))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("@/lib/admin-guard.server");
    await assertAdmin(context.supabase, context.userId);
    if (data.userId === context.userId) {
      return { ok: false as const, error: "You can't remove your own admin account." };
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.auth.admin.deleteUser(data.userId);
    if (error) return { ok: false as const, error: error.message };
    return { ok: true as const };
  });
