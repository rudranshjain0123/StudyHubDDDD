import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async ({ location }) => {
    // getSession is read from local storage and refreshed in the background,
    // so the guard resolves instantly instead of waiting on a network call.
    const { data, error } = await supabase.auth.getSession();
    if (error || !data.session?.user) {
      // Keep the destination (e.g. a shared ?workId link) so login can return to it.
      throw redirect({ to: "/", search: { next: location.href } });
    }
    return { user: data.session.user };
  },
  component: () => <Outlet />,
});
